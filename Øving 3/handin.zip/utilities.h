
//returns a random integer between lowerLim and upperLim inclusive
int randomWithLimits(int lowerLim, int upperLim);

//compares two doubles, test passes if difference < maxError
void testDeviation(double compareOperand, double toOperand, double maxError, string name);

void testCallByValue();

void testCallByReference();

void testSwapNumbers();

void testString();
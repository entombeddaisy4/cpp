#include "std_lib_facilities.h"
#include "temps.h"

istream& operator>>(istream& is, Temps& t) {
    
}
#include "std_lib_facilities.h"

void wordsToFile();

void copyWithLinenumbers();

void characterStats();
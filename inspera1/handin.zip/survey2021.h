#include "std_lib_facilities.h"

//Declare relevant functions for the task. 

map<string, int> mapSurvey();
vector<string> sortVector(map<string,int> unsortedMap);
void surveyResults(map<string,int> surveyMap, vector<string> sortedVector);